from flask import Flask, jsonify, render_template
import psutil
import time
import smtplib

app = Flask(__name__)

def get_metrics():
    """Fetch system usage metrics and generate alerts if thresholds are exceeded."""
    metrics = {
        "CPU_Usage (%)": psutil.cpu_percent(interval=1),
        "RAM_Usage (%)": psutil.virtual_memory().percent,
        "Disk_Free_Space (GB)": round(psutil.disk_usage('/').free / 1e9, 2),
        "Uptime (hours)": round((time.time() - psutil.boot_time()) / 3600, 2)
    }

    # Alerts
    alerts = []
    if metrics["CPU_Usage (%)"] > 80:
        alerts.append("High CPU usage!")
        send_email_alert("High CPU usage detected!")
    if metrics["RAM_Usage (%)"] > 80:
        alerts.append("High RAM usage!")
        send_email_alert("High RAM usage detected!")
    if metrics["Disk_Free_Space (GB)"] < 20:
        alerts.append("Low disk space!")
        send_email_alert("Low disk space detected!")

    metrics["Alerts"] = alerts
    return metrics

def send_email_alert(alert_message):
    """Send an email alert."""
    sender_email = "your_email@gmail.com"
    receiver_email = "receiver_email@gmail.com"
    password = "gfms ectf ivyr ojnk"

    subject = "System Alert"
    body = f"Alert: {alert_message}"
    message = f"Subject: {subject}\n\n{body}"

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message)
        print("Email alert sent!")
    except Exception as e:
        print(f"Failed to send email: {e}")

@app.route('/metrics', methods=['GET'])
def metrics():
    """API endpoint to return system metrics."""
    return jsonify(get_metrics())

@app.route('/')
def dashboard():
    """Render the dashboard page."""
    return render_template('index.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
